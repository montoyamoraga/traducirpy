# traducirpy

## Description

A project by Aarón Montoya-Moraga.

## Installation

```bash
pip install traducir
```

## Use

Import Python module

```Python
import traducir
```

Functions

```Python
traducir.ecfrasis(texto)
```

## License

MIT
